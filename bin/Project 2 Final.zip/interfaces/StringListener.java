package interfaces;

public interface StringListener {
	
	public void textEmitter(String text);
	
}

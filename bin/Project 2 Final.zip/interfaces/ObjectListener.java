package interfaces;

import model.Person;

public interface ObjectListener {
	
	public void objectEmitter(Person person1);
 
}

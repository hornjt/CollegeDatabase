package interfaces;

public interface DoubleListener {
	
	public void doubleEmitter(Double number);

}

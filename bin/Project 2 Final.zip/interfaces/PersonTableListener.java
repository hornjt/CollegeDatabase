package interfaces;

public interface PersonTableListener {
	
	public void rowDeleted(int row);

}

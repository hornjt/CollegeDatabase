package main;

import gui.MainFrame;
/**
 * 
 * @author Jon Horn
 * @version 2.2
 * CST 242 - Spring 2015
 * Project 2
 * Final Release Date - April 10, 2015
 *
 */

public class Project2Main {
	
	/**
	 * 
	 * @param args
	 * Main Method
	 */
	public static void main(String[] args) {
		new MainFrame();
	}

}

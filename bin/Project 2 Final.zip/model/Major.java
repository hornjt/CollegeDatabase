package model;

public enum Major {
	computerScience,
	math,
	it
}

package model;

public enum Model {
	computerScience,
	math,
	it
}

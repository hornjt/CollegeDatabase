package model;


public class IllegalInput extends Exception {
	
	public IllegalInput(String s) {
		super(s);
	}
	
}